package com.hibernate.ana.spring.hibernate.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hibernate.ana.spring.hibernate.dao.MembershipDAO;
import com.hibernate.ana.spring.hibernate.model.Membership;

@Service
public class MembershipServiceImpl implements MembershipService{
	@Autowired
	private MembershipDAO membershipDao;

	@Override
	public List<Membership> getAllMemberships() {
		// TODO Auto-generated method stub
		List<Membership> memberships = membershipDao.getAllMemberships();
		return memberships;
	}

	@Override
	public void createMembership(Membership membership) {
		// TODO Auto-generated method stub
		membershipDao.createMembership(membership);
	}
	
	

}
