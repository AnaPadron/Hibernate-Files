package com.hibernate.ana.spring.hibernate.service;

import java.util.List;

import com.hibernate.ana.spring.hibernate.model.Membership;

public interface MembershipService {
	public List<Membership> getAllMemberships();
	public void createMembership(Membership membership);
}
