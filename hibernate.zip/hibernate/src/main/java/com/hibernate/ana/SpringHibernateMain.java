package com.hibernate.ana;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.hibernate.ana.spring.hibernate.model.Membership;
import com.hibernate.ana.spring.hibernate.service.MembershipService;

public class SpringHibernateMain {

	public static void main(String[] args) { 
		ApplicationContext context = 
				new ClassPathXmlApplicationContext(
						"/META-INF/spring/app-context.xml");
		MembershipService membershipService = context.getBean("membershipServiceImpl",MembershipService.class);
		
		Membership membership = new Membership();
		membership.setStatusCode("Active");
		membership.setExpiradtionDate("11/30/2020");
		membership.setId(1234);
		membershipService.createMembership(membership);

		for(Membership m : membershipService.getAllMemberships())
		{
			System.out.println(m);
		}
	}

}
