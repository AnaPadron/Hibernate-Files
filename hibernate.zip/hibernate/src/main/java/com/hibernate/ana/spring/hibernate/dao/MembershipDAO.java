package com.hibernate.ana.spring.hibernate.dao;

import java.util.List;

import com.hibernate.ana.spring.hibernate.model.Membership;

public interface MembershipDAO {
	public List<Membership> getAllMemberships();
	public void createMembership(Membership membership);

}
