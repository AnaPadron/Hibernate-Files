package com.hibernate.ana.spring.hibernate.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "membership")
public class Membership {
	
	@Id
	@Column(name = "membership_num")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	
	@Column(name = "status_cd")
	private String statusCode;
	
	@Column(name = "expiration_dttm")
	private String expirationDate;

	

	public Membership(Integer id, String statusCode, String expirationDate) {
		super();
		this.id = id;
		this.statusCode = statusCode;
		this.expirationDate = expirationDate;
	}

	public Membership() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		
		Membership other = (Membership) obj;
		if (expirationDate == null) {
			if (other.expirationDate != null)
				return false;
		} else if (!expirationDate.equals(other.expirationDate))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (statusCode == null) {
			if (other.statusCode != null)
				return false;
		} else if (!statusCode.equals(other.statusCode))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Membership [id=" + id + ", statusCode=" + statusCode + ", expiradtionDate=" + expirationDate + "]";
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getExpiradtionDate() {
		return expirationDate;
	}

	public void setExpiradtionDate(String expirationDate) {
		this.expirationDate = expirationDate;
	}
	

}
