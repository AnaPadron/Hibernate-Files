package com.hibernate.ana.spring.hibernate.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceUnit;
import javax.persistence.TypedQuery;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.ejb.EntityManagerFactoryImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.hibernate.ana.spring.hibernate.model.Membership;

@Repository
@Transactional(readOnly = true)
public class MembershipDaoImpl implements MembershipDAO {
	@Autowired
	private SessionFactory sessionFactory;
	
	
	

	@Override
	public List<Membership> getAllMemberships() {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		String hql = "FROM com.hibernate.ana.spring.hibernate.model.Membership";
		Query query = session.createQuery(hql);
		
		
		List<Membership> membership = query.list(); //no type warning
		
		return membership;
	}

	@Transactional(readOnly = false)
	public void createMembership(Membership membership) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		session.save(membership);
		
		
	}

}
