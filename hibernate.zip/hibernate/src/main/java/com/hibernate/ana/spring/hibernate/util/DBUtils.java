package com.hibernate.ana.spring.hibernate.util;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.sql.DataSource;

import javax.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class DBUtils {
	@Autowired
	private DataSource dataSource;
	
	@PostConstruct
	public void initialize(){
		try {
			Connection connection = dataSource.getConnection();
			Statement statement = connection.createStatement();
			statement.execute("DROP TABLE IF EXISTS membership");
			statement.executeUpdate("CREATE TABLE membership("+
			"membership_num Primary key, " +
			"status_cd varchar(30) not null, "+
			"expiration_dttm varchar(30) not null)"
			);
			statement.executeUpdate("INSERT INTO membership" +
			"(status_cd , expiration_dttm) "+
			"VALUES "+ "('Active' , '12/11/2021')"
			);
			
			ResultSet rs = statement.executeQuery("select * from membership");
			
			while(rs.next())
			{
				String status = rs.getString("status_cd");
				String expiration = rs.getString("expiration_dttm");
				int id = rs.getInt("membership_num");
				System.out.println("Id="+id+" status= "+status+ " date= "+ expiration);
			}
			statement.close();
			connection.close();
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
